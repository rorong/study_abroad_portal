class CourseSubjectRequirement < ApplicationRecord
end
